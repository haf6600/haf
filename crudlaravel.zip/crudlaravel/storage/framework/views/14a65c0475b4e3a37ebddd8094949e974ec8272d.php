
<?php $__env->startSection('title', 'Data Mahasiswa'); ?>
<?php $__env->startSection('content'); ?>

<?php if(session()->has('beehasil')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('behasil')); ?>

    </div>
<?php endif; ?>

    <div class="container mt-5">
        <div class="card">
            <div class="card-header">
                <h3>Data Mahasiswa</h3>
            </div>

            <div class="card-body">
                <div class="form-group">
                    <a href="<?php echo e(route('mahasiswa.create')); ?>" class="btn btn-success">Tambah</a>
                </div>
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>NIM</th>
                            <th>Nama</th>
                            <th>Program Studi</th>
                            <th>Fakultas</th>
                            <th>Sunting</th>
                        </tr>                    
                    </thead>
                    <tbody>
                        <?php
                            $increment = 1;
                        ?>
                        <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($increment++); ?></td>
                            <td><?php echo e($item->nim); ?></td>
                            <td><?php echo e($item->nama_lengkap); ?></td>
                            <td><?php echo e($item->prodi); ?></td>
                            <td><?php echo e($item->fakultas); ?></td>
                            <td>
                                <a href="<?php echo e(route('mahasiswa.edit', $item->id)); ?>">Edit</a>
                                <form action="<?php echo e(route('mahasiswa.destroy', $item->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</button>
                                </form>
                            </td>
                        </tr>                                                    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crudlaravel\resources\views/mahasiswa/index.blade.php ENDPATH**/ ?>
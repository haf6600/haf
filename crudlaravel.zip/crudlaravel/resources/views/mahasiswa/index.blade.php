@extends('layouts.main')
@section('title', 'Data Mahasiswa')
@section('content')

@if(session()->has('beehasil'))
    <div class="alert alert-success">
        {{ session()->get('behasil')}}
    </div>
@endif

    <div class="container mt-5">
        <div class="card">
            <div class="card-header">
                <h3>Data Mahasiswa</h3>
            </div>

            <div class="card-body">
                <div class="form-group">
                    <a href="{{ route('mahasiswa.create') }}" class="btn btn-success">Tambah</a>
                </div>
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>NIM</th>
                            <th>Nama</th>
                            <th>Program Studi</th>
                            <th>Fakultas</th>
                            <th>Sunting</th>
                        </tr>                    
                    </thead>
                    <tbody>
                        @php
                            $increment = 1;
                        @endphp
                        @foreach ($mahasiswa as $item)
                        <tr>
                            <td>{{ $increment++ }}</td>
                            <td>{{ $item->nim }}</td>
                            <td>{{ $item->nama_lengkap }}</td>
                            <td>{{ $item->prodi }}</td>
                            <td>{{ $item->fakultas }}</td>
                            <td>
                                <a href="{{ route('mahasiswa.edit', $item->id) }}">Edit</a>
                                <form action="{{ route('mahasiswa.destroy', $item->id) }}" method="post">
                                    @csrf
                                    @method('delete')
                                    <button type="submit" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</button>
                                </form>
                            </td>
                        </tr>                                                    
                        @endforeach
                </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection